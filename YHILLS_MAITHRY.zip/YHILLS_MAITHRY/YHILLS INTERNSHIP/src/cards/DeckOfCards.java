package cards;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.*;

// Define the Suit enum
enum Suit {
    SPADE, CLUB, HEART, DIAMOND
}

// Define the Rank enum
enum Rank {
    A, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN, J, Q, K
}

// Define the Card class
class Card {
    private final Suit suit;
    private final Rank rank;

    public Card(Suit suit, Rank rank) {
        this.suit = suit;
        this.rank = rank;
    }

    public Suit getSuit() {
        return suit;
    }

    public Rank getRank() {
        return rank;
    }

    @Override
    public String toString() {
        return rank + " of " + suit;
    }
}

// Define the Deck class
class Deck {
    private List<Card> cards = new ArrayList<>();

    public Deck() {
        initializeDeck();
        shuffle(); // Shuffle the deck when created
    }

    private void initializeDeck() {
        for (Suit suit : Suit.values()) {
            for (Rank rank : Rank.values()) {
                cards.add(new Card(suit, rank));
            }
        }
    }

    public void shuffle() {
        // Fisher-Yates shuffle algorithm
        Random random = new Random();
        for (int i = cards.size() - 1; i > 0; i--) {
            int index = random.nextInt(i + 1);
            Card temp = cards.get(index);
            cards.set(index, cards.get(i));
            cards.set(i, temp);
        }
    }

    public Card drawCard() {
        if (cards.isEmpty()) {
            throw new IllegalStateException("No more cards in the deck");
        }
        return cards.remove(cards.size() - 1);
    }

    public int size() {
        return cards.size();
    }
}

// Define the Comparator for Card
class CardComparator implements Comparator<Card> {
    @Override
    public int compare(Card c1, Card c2) {
        // Compare by color first
        int colorComparison = getColor(c1).compareTo(getColor(c2));
        if (colorComparison != 0) return colorComparison;

        // If colors are the same, compare by suit
        int suitComparison = c1.getSuit().compareTo(c2.getSuit());
        if (suitComparison != 0) return suitComparison;

        // Finally, compare by rank
        return c1.getRank().compareTo(c2.getRank());
    }

    private String getColor(Card card) {
        return (card.getSuit() == Suit.HEART || card.getSuit() == Suit.DIAMOND) ? "Red" : "Black";
    }
}


//Main class to execute the card game logic
public class DeckOfCards {
	public static void main(String[] args) {
	    Scanner scanner = new Scanner(System.in);
	    String response;

	    do {
	        Deck deck = new Deck();
	        List<Card> drawnCards = new ArrayList<>();
	        for (int i = 0; i < 20; i++) {
	            drawnCards.add(deck.drawCard());
	        }

	        Collections.sort(drawnCards, new CardComparator());

	        // Print shuffled cards
	        System.out.println("Shuffled cards:");
	        for (Card card : drawnCards) {
	            System.out.println(card);
	        }

	        System.out.println("Deck size: " + deck.size());

	        System.out.println("\nShuffle again? (yes/no): ");
	        response = scanner.nextLine().trim().toLowerCase();
	    } while (response.equals("yes"));

	    System.out.println("Exiting program. Thank you!");
	}

}


